#pragma once

typedef struct s_agent {
    char *name;
    int power;
    int strength;
}              t_agent;
