#include "minilibmx.h"

bool mx_isdigit(int c) {
	return c >= 48 && c <= 57;
}

