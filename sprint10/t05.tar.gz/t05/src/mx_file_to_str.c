#include "file_to_str.h"

char *mx_file_to_str(const char *filename) {
    int fd = open(filename, O_RDONLY), byte, size;
    char *str = NULL;
    char buff[80];

    if (fd == -1)
        return NULL;

    byte = read(fd, &buff, sizeof(buff));
    while (byte != 0) {
        size += byte;
        byte = read(fd, &buff, sizeof(buff));
    }
    close(fd);
    str = mx_strnew(size);

    fd = open(filename, O_RDONLY);
    byte = read(fd, str, size);
    close(fd);
    return str;
}

// int main (int argc, char ** argv) {
//     if (argc != 2)
//         return 0;
//     char *str = mx_file_to_str(argv[1]);
//     printf("str: %s\n", str);
//     return 0;
// }
